const grid = document.querySelector(".grid");
const popup = document.getElementById("popup");
const message = document.getElementById("message");
const sound = document.getElementById("sound");

const wishes = [
    "Chúc em năm mới học giỏi hơn nữa và đạt nhiều thành tích tốt!",
    "Chúc em luôn chăm ngoan, vâng lời thầy cô và ba mẹ!",
    "Chúc em một năm mới đầy niềm vui và năng lượng tích cực!",
    "Chúc em tự tin hơn, mạnh dạn hơn mỗi ngày!",
    "Chúc em đạt điểm cao trong mọi bài kiểm tra!",
    "Chúc em khám phá nhiều điều thú vị trong học tập!",
    "Chúc em luôn yêu thích môn học và tiến bộ từng ngày!",
    "Chúc em kết bạn tốt, đoàn kết với mọi người!",
    "Chúc em trở thành học sinh xuất sắc!",
    "Chúc em luôn vui vẻ và hạnh phúc!",
    "Chúc em có thật nhiều cơ hội mới trong năm học!",
    "Chúc em giữ gìn sức khỏe và học tốt!",
    "Chúc em mỗi ngày đến trường là một ngày vui!",
    "Chúc em sáng tạo, chủ động và tự tin!",
    "Chúc em thêm nhiều trải nghiệm bổ ích!",
    "Chúc em chăm chỉ, kiên trì và không bỏ cuộc!",
    "Chúc em hoàn thành tốt mọi mục tiêu đã đặt ra!",
    "Chúc em luôn mỉm cười và gặp nhiều may mắn!",
    "Chúc em trở thành phiên bản tốt hơn của chính mình!",
    "Chúc em giành thật nhiều phần thưởng trong học tập!"
];

for (let i = 0; i < 20; i++) {
    const box = document.createElement("div");
    box.className = "lixi";
    box.onclick = () => openWish();
    grid.appendChild(box);
}

function openWish() {
    const random = wishes[Math.floor(Math.random() * wishes.length)];
    message.textContent = random;
    popup.classList.remove("hidden");
    sound.play();
}

function closePopup() {
    popup.classList.add("hidden");
}